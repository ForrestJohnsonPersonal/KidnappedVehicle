#ifndef MULTIV_GAUSS_H
#define MULTIV_GAUSS_H

double multiv_prob(double sig_x, double sig_y, double x_obs, double y_obs,
                   double mu_x, double mu_y);

#endif  // MULTIV_GAUSS_H