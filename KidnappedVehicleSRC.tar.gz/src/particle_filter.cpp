/**
 * particle_filter.cpp
 *
 * Created on: Dec 12, 2016
 * Author: Tiffany Huang
 */

#include "particle_filter.h"

#include <math.h>
#include <algorithm>
#include <iostream>
#include <iterator>
#include <numeric>
#include <random>
#include <string>
#include <vector>

#include "helper_functions.h"
//#include "multiv_gauss.h"
#include <cmath>

using std::string;
using std::vector;

void ParticleFilter::init(double x, double y, double theta, double std[]) {
  /**
   * TODO: Set the number of particles. Initialize all particles to 
   *   first position (based on estimates of x, y, theta and their uncertainties
   *   from GPS) and all weights to 1. 
   * TODO: Add random Gaussian noise to each particle.
   * NOTE: Consult particle_filter.h for more information about this method 
   *   (and others in this file).
   */
  num_particles = 10;  // TODO: Set the number of particles
//  particles = std::vector<Particle>();
  std::random_device rd{};
  std::mt19937 gen{rd()};
  std::normal_distribution<double> d_X{x,std[0]};
  std::normal_distribution<double> d_Y{y,std[1]};
  std::normal_distribution<double> d_theta{theta,std[2]};
  
  for (int i=0; i< num_particles; ++i){
    Particle newParticle;
    newParticle.id = i;
    newParticle.x = std::round(d_X(gen));//Add noise to original GPS guess.
    newParticle.y = std::round(d_Y(gen));//Add noise to original GPS guess.
    newParticle.theta = std::round(d_theta(gen));//Add noise to original GPS guess.
    newParticle.weight = 1;
    particles.push_back(newParticle);
 //   std::cout << "Particle id=" << newParticle.id << " X=" << newParticle.x << " Y=" << newParticle.y << std::endl;
  }
  is_initialized = 1;
}

void ParticleFilter::prediction(double delta_t, double std_pos[], 
                                double velocity, double yaw_rate) {
  /**
   * TODO: Add measurements to each particle and add random Gaussian noise.
   * NOTE: When adding noise you may find std::normal_distribution 
   *   and std::default_random_engine useful.
   *  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
   *  http://www.cplusplus.com/reference/random/default_random_engine/
   */
  std::cout << "Beginning Prediction" << std::endl;
    std::random_device rd{};
  std::mt19937 gen{rd()};
  std::normal_distribution<double> d_X{0.0,std_pos[0]};
  std::normal_distribution<double> d_Y{0.0,std_pos[1]};
  std::normal_distribution<double> d_theta{0.0,std_pos[2]};
  for (int i=0; i< num_particles; ++i){
    double newX = particles[i].x + (velocity/yaw_rate)*(sin(particles[i].theta + yaw_rate*delta_t)-sin(particles[i].theta));//Add X-distance based on velocity and yaw.
    double newY = particles[i].y + (velocity/yaw_rate)*(cos(particles[i].theta)-cos(particles[i].theta + yaw_rate*delta_t));//Add Y-distance based on velocity and yaw.
    double newTheta = particles[i].theta + yaw_rate;//Add change in yaw.
                                          
    particles[i].x = newX + std::round(d_X(gen));//Add noise.
    particles[i].y = newY + std::round(d_Y(gen));//Add noise.
    particles[i].theta = newTheta + std::round(d_theta(gen));//Add noise.
    std::cout << "Prediction: Particle id=" << particles[i].id << " X=" << particles[i].x << " Y=" << particles[i].y << " Weight=" << particles[i].weight << std::endl;
  }
}

double ParticleFilter::multiv_prob(double sig_x, double sig_y, double x_obs, double y_obs,
                   double mu_x, double mu_y) {
  // calculate normalization term
  double gauss_norm;
  gauss_norm = 1 / (2 * M_PI * sig_x * sig_y);

  // calculate exponent
  double exponent;
  exponent = (pow(x_obs - mu_x, 2) / (2 * pow(sig_x, 2)))
               + (pow(y_obs - mu_y, 2) / (2 * pow(sig_y, 2)));
    
  // calculate weight using normalization terms and exponent
  double weight;
  weight = gauss_norm * exp(-exponent);
    
  return weight;
}

void ParticleFilter::dataAssociation(vector<LandmarkObs> predicted, 
                                     vector<LandmarkObs>& observations) {
//double ParticleFilter::dataAssociation(vector<LandmarkObs> predicted, 
//                                     const vector<LandmarkObs>& observations, double std_landmark[]) {
  /**
   * TODO: Find the predicted measurement that is closest to each 
   *   observed measurement and assign the observed measurement to this 
   *   particular landmark.
   * NOTE: this method will NOT be called by the grading code. But you will 
   *   probably find it useful to implement this method and use it as a helper 
   *   during the updateWeights phase.
   */
//  std::cout << "Beginning dataAssociation" << std::endl;
//  double totalParticleWeight = 1;
  for (int i=0; i< observations.size(); ++i){
//    LandmarkObs closestPredict;
//    double closestTransformXm;
//    double closestTransformYm;
  	double closestDist = 10000000;//Some high value.
    int closestID;
  	for (int j=0; j< predicted.size(); ++j){//Loop through all predicted landmarks and find the closest match to the observed
//      double transformXm = predicted[j].x + (cos(-M_PI/2)*observations[i].x)-(sin(-M_PI/2)*observations[i].y);
//      double transformYm = predicted[j].y + (sin(-M_PI/2)*observations[i].x)+(cos(-M_PI/2)*observations[i].y);
//      double distance = dist(transformXm, transformYm, predicted[j].x, predicted[j].y);
      double distance = dist(observations[i].x, observations[i].y, predicted[j].x, predicted[j].y);
      if (distance < closestDist){
      	closestDist = distance;
        closestID = predicted[j].id;
//      	closestPredict.id = predicted[j].id;
//      	closestPredict.x = predicted[j].x;
//      	closestPredict.y = predicted[j].y;
//        closestTransformXm = transformXm;
//        closestTransformYm = transformYm;
        }
      observations[i].id = closestID;
    }
//    observations[i].id = closestObs.id;
//    x_Tobs = transformXm;//the transformed observations(to map coord.) X.
//    y_Tobs = transformYm;//the transformed observations(to map coord.) Y.
//    mu_x = closestPredict.x;//X coordinate of nearest landmark.
//    mu_y = closestPredict.y;//Y coordinate of nearest landmark.
//    totalParticleWeight *= multiv_prob(std_landmark[0], std_landmark[1], x_Tobs, y_Tobs, mu_x, mu_y);
//    double nextWeight = multiv_prob(std_landmark[0], std_landmark[1], closestTransformXm, closestTransformYm, closestPredict.x, closestPredict.y);
//    std::cout << " Weight=" << nextWeight << " std_landmark[0]=" << std_landmark[0] << " std_landmark[1]=" <<  std_landmark[1] << " closestTransformXm=" <<  closestTransformXm << " closestTransformYm=" << closestTransformYm << " closestPredict.x=" <<  closestPredict.x << " closestPredict.y=" <<  closestPredict.y << std::endl;
//    totalParticleWeight = totalParticleWeight*nextWeight;
  }
//  std::cout << " Weight=" << totalParticleWeight << std::endl;
//  return totalParticleWeight;
  return;
}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[], 
                                   const vector<LandmarkObs> &observations, 
                                   const Map &map_landmarks) {
  /**
   * TODO: Update the weights of each particle using a mult-variate Gaussian 
   *   distribution. You can read more about this distribution here: 
   *   https://en.wikipedia.org/wiki/Multivariate_normal_distribution
   * NOTE: The observations are given in the VEHICLE'S coordinate system. 
   *   Your particles are located according to the MAP'S coordinate system. 
   *   You will need to transform between the two systems. Keep in mind that
   *   this transformation requires both rotation AND translation (but no scaling).
   *   The following is a good resource for the theory:
   *   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
   *   and the following is a good resource for the actual equation to implement
   *   (look at equation 3.33) http://planning.cs.uiuc.edu/node99.html
   */
  std::cout << "Beginning UpdateWeights" << std::endl;
  double sig_x = std_landmark[0];
  double sig_y = std_landmark[1];
  double gauss_norm = 1 / (2 * M_PI * sig_x * sig_y);
  
  //Loop through all the particles and for each one do a filter of possible landmarks from the map within sensing range.
  for (int i=0; i<num_particles; ++i){
    //Convert all observations to transformed.
    vector<LandmarkObs> T_OBS;
    for (unsigned int j = 0; j < observations.size(); ++j)
    {
      double x_map = observations[j].x * cos(particles[i].theta) - observations[j].y * sin(particles[i].theta) + particles[i].x;
      double y_map = observations[j].x * sin(particles[i].theta) + observations[j].y * cos(particles[i].theta) + particles[i].y;
      T_OBS.push_back (LandmarkObs{observations[j].id, x_map, y_map}); 
    }
    
    //Generate list of landmarks in range.
    std::vector<LandmarkObs> landmarkInRange_list;
    for (int j=0; j< map_landmarks.landmark_list.size(); ++j){
      if (dist(map_landmarks.landmark_list[j].x_f, map_landmarks.landmark_list[j].y_f, particles[i].x, particles[i].y) <= sensor_range){
      	double newLandmarkX = map_landmarks.landmark_list[j].x_f;
        double newLandmarkY = map_landmarks.landmark_list[j].y_f;
        double newLandmarkID = map_landmarks.landmark_list[j].id_i;
        LandmarkObs newLandmark;
        newLandmark.x = newLandmarkX;
        newLandmark.y = newLandmarkY;
        newLandmark.id = newLandmarkID;
        landmarkInRange_list.push_back(newLandmark);
      }
      
      vector<int> finalObsAssociations;
      vector<double> sense_x;
	  vector<double> sense_y;
      dataAssociation(landmarkInRange_list, T_OBS);//Call the "dataAssociation" function and determine 'Which observed landmark matches the closest to the predicted landmarks.
	  particles[i].weight = 1.0; //reset but after cycling through all observations this.
      //      std::cout << "Particle id=" << particles[i].id << " X=" << particles[i].x << " Y=" << particles[i].y << " Weight=" << particles[i].weight << std::endl;
      double map_x, map_y, mu_x, mu_y;
      for (unsigned int t = 0; t < T_OBS.size(); ++t)
      {
        map_x =  T_OBS[t].x;
        map_y =  T_OBS[t].y;
        for (unsigned int p = 0; p < landmarkInRange_list.size(); ++p)
        {
          // Associate predicted landmark in-range with transformed observation
          if (landmarkInRange_list[p].id == T_OBS[t].id)
          {
            mu_x = landmarkInRange_list[p].x;
            mu_y = landmarkInRange_list[p].y;
          }
        }
      
        // Calc particle weight
        particles[i].weight *= gauss_norm * exp(-(0.5*pow( (map_x - mu_x)/sig_x, 2.0 )+0.5*pow( (map_y - mu_y)/sig_y, 2.0 )));;
      
        // Append particle observation associations
        finalObsAssociations.push_back(T_OBS[t].id);
        sense_x.push_back(map_x);
        sense_y.push_back(map_y);
        SetAssociations(particles[i], finalObsAssociations, sense_x, sense_y);
      }
      std::cout << "UpdatedWeight Particle id=" << particles[i].id << " X=" << particles[i].x << " Y=" << particles[i].y << " Weight=" << particles[i].weight << std::endl;
 //     particles[i] = p.weight;
    }
  }
}

bool sortByWeight ( Particle x1, Particle x2 )
{
return ( x1.weight > x2.weight ) ;
}

void ParticleFilter::resample() {
  /**
   * TODO: Resample particles with replacement with probability proportional 
   *   to their weight. 
   * NOTE: You may find std::discrete_distribution helpful here.
   *   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution
   */
  std::cout << "Beginning resample" << std::endl;
  double sumTotal = 0;
  for (int i=0; i<num_particles; ++i){
    sumTotal += particles[i].weight;
  }
  std::vector<Particle> NormalizedParticlesWeights;
  for (int i=0; i<num_particles; ++i){
    Particle normalizedParticle = Particle();
    double normWeight = 0; 
    if (particles[i].weight > 0){
      normWeight = particles[i].weight / sumTotal;
    }
    normalizedParticle.weight = normWeight;
    normalizedParticle.x = particles[i].x;
    normalizedParticle.y = particles[i].y;
    normalizedParticle.theta = particles[i].theta;
    normalizedParticle.id = particles[i].id;
    NormalizedParticlesWeights.push_back(normalizedParticle);
    std::cout << "NormalizedParticle id=" << normalizedParticle.id << " X=" << normalizedParticle.x << " Y=" << normalizedParticle.y << " Weight=" << normalizedParticle.weight << std::endl;
  }
  sort(NormalizedParticlesWeights.begin(), NormalizedParticlesWeights.end(), sortByWeight);
//  std::cout << "Sorted-resample" << std::endl;
  int index = 0;
  std::random_device rd; // obtain a random number from hardware
  std::mt19937 gen(rd()); // seed the generator
  std::uniform_real_distribution<> distr(0.0,2.0*NormalizedParticlesWeights[0].weight);//Take the largest weight and scale by 2x.
  double beta = distr(gen);
  std::cout << "Highest NormalizedParticlesWeights[0]=" << NormalizedParticlesWeights[0].weight << std::endl;
  
//  std::vector<double> resamplingWeights  = [num_particles];
  std::vector<Particle> newParticles;
  for (int i=0; i<num_particles; ++i){
    beta = beta + distr(gen);
    std::cout << "beta=" << beta << std::endl;
    while ((NormalizedParticlesWeights[index].weight < beta) && (index < num_particles)){
        beta = beta - NormalizedParticlesWeights[index].weight;
        index = index + 1;
      	std::cout << "beta=" << beta << " index=" << index << std::endl;
      }
    newParticles.push_back(NormalizedParticlesWeights[index]);
    std::cout << "Resampled Particle id=" << NormalizedParticlesWeights[index].id << " X=" << NormalizedParticlesWeights[index].x << " Y=" << NormalizedParticlesWeights[index].y << " Weight=" << NormalizedParticlesWeights[index].weight << std::endl;
    }
  particles = newParticles;
}

void ParticleFilter::SetAssociations(Particle& particle, 
                                     const vector<int>& associations, 
                                     const vector<double>& sense_x, 
                                     const vector<double>& sense_y) {
  // particle: the particle to which assign each listed association, 
  //   and association's (x,y) world coordinates mapping
  // associations: The landmark id that goes along with each listed association
  // sense_x: the associations x mapping already converted to world coordinates
  // sense_y: the associations y mapping already converted to world coordinates
  particle.associations= associations;
  particle.sense_x = sense_x;
  particle.sense_y = sense_y;
}

string ParticleFilter::getAssociations(Particle best) {
  vector<int> v = best.associations;
  std::stringstream ss;
  copy(v.begin(), v.end(), std::ostream_iterator<int>(ss, " "));
  string s = ss.str();
  s = s.substr(0, s.length()-1);  // get rid of the trailing space
  return s;
}

string ParticleFilter::getSenseCoord(Particle best, string coord) {
  vector<double> v;

  if (coord == "X") {
    v = best.sense_x;
  } else {
    v = best.sense_y;
  }

  std::stringstream ss;
  copy(v.begin(), v.end(), std::ostream_iterator<float>(ss, " "));
  string s = ss.str();
  s = s.substr(0, s.length()-1);  // get rid of the trailing space
  return s;
}